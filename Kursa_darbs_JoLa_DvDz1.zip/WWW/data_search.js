  const articles = [
    {
      title: "Virtuālā nākotne",
      description: "Kā VR un AI maina mūsu pasauli?",
      url: "404.html"
    },
    {
      title: "Ilgtspējas uzliesmojums",
      description: "Klimatam draudzīgākas metodes uzņēmumiem.",
      url: "404.html"
    },
    {
      title: "Digitālā māksla",
      description: "Kas notiek ar mākslu interneta laikmetā?",
      url: "404.html"
    },
    {
      title: "Kultūras uzliesmojums",
      description: "Māksla kā protesta valoda.",
      url: "404.html"
    },
    {
      title: "Par mums",
      description: "Kas mēs esam un kāda ir dzīves jēga?",
      url: "ParMums.html"
    },
    {
      title: "Teātris Rīgā atdzimst",
      description: "Jaunas izrādes, jauni režisori, jauns vilnis.",
      url: "Kultura.html"
    },
    {
      title: "Latvijas mākslinieki Berlīnē",
      description: "Latvijas māksla starptautiskā forumā.",
      url: "Kultura.html"
    },
    {
      title: "Kā dzima Dziesmu svētki",
      description: "Ceļojums uz 1873. gadu un svētku rašanos.",
      url: "DziesmuSvetki_Raksts.html"
    },
    {
      title: "Skolu reforma tuvplānā",
      description: "Diskusijas par izglītības iestāžu apvienošanu.",
      url: "Aktualitates.html"
    },
    {
      title: "Pavasara plūdi Kurzemē",
      description: "Lauki applūduši – piesardzības pasākumi.",
      url: "Aktualitates.html"
    },
    {
      title: "Sabiedriskais transports maina maršrutus",
      description: "Izmaiņas Rīgas tramvaju un autobusu kustībā.",
      url: "Aktualitates.html"
    },
    {
      title: "Dziesmu svētku biļetes izpārdotas",
      description: "Biļetes izķertas stundas laikā.",
      url: "Aktualitates.html"
    },
    {
      title: "Bērnu drošība uz ceļa",
      description: "Jauna kampaņa skolēnu drošībai.",
      url: "Aktualitates.html"
    }
  ];
